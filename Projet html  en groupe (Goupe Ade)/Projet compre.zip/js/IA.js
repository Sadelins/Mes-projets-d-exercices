
// const btt = document.querySelector("button");

// btt.onclick = function () {


//   let vocale = window.speechSynthesis;
//   let lire = new SpeechSynthesisUtterance("Good monning. How are you ! Do you want to visit our site ? Estudio Digital Branding | Web | SEO");
//   lire.lang = 'fr-FR';
//   vocale.speak(lire)
// }
